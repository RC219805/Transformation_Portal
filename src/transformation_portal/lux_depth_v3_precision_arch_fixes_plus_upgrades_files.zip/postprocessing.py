"""Postprocessing module for DA3 depth maps.

Handles metric scaling, filtering, and edge preservation.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import logging

logger = logging.getLogger(__name__)

import numpy as np
from scipy.ndimage import median_filter

from .config import PostprocessingConfig
from .inference import DepthResult

# Edge refinement is optional (and may not be present in stripped-down deployments).
try:
    from .edge_refinement import DepthRefiner  # type: ignore
except ImportError:
    DepthRefiner = None


class _NoOpDepthRefiner:
    """Fallback refiner used when the optional edge_refinement module isn't available."""

    def __init__(self, *args, **kwargs):
        self._stats = {"enabled": False, "available": False}

    def refine(self, depth: np.ndarray, image: np.ndarray) -> np.ndarray:
        return depth

    def get_stats(self):
        return dict(self._stats)


class Postprocessor:
    """Postprocessor for depth maps."""

    def __init__(self, config: PostprocessingConfig):
        self.config = config

        # Initialize edge refinement module
        refinement_cfg = getattr(config, "refinement", None)
        if DepthRefiner is None or refinement_cfg is None:
            self.refiner = _NoOpDepthRefiner()
        else:
            try:
                self.refiner = DepthRefiner(refinement_cfg)
            except Exception:
                self.refiner = _NoOpDepthRefiner()

    def process(self, result: DepthResult) -> DepthResult:
        """Apply postprocessing to depth result."""
        depth = result.depth_map.copy()

        # Metric scaling
        if self.config.apply_metric_scaling:
            depth = depth * self.config.scale_factor

        # Filtering
        if self.config.apply_median_filter:
            depth = median_filter(depth, size=self.config.median_kernel_size)

        if self.config.apply_bilateral_filter:
            depth = self._bilateral_filter(
                depth, result.original_image, self.config.bilateral_sigma_color, self.config.bilateral_sigma_space
            )

        # Edge preservation
        if self.config.preserve_edges:
            depth = self._preserve_edges(depth, result.original_image, self.config.edge_threshold)

        # Edge-aware refinement (Optional Module)
        if self.refiner and getattr(self.config.refinement, "enable_refinement", False):
            depth = self.refiner.refine(depth, result.original_image)

        # Update result
        result.depth_map = depth
        result.metadata["postprocessing"] = self.config.__dict__
        result.metadata["refinement"] = self.refiner.get_stats()

        return result

def _bilateral_filter(self, depth: np.ndarray, image: np.ndarray, sigma_color: float, sigma_space: float) -> np.ndarray:
    """Apply a bilateral filter (edge-preserving smoothing).

    Key invariant: **preserve numeric precision**. Depth is filtered in float32 space (no uint8 quantization).

    Notes on `sigmaColor` scaling:
      - OpenCV interprets `sigmaColor` in the same units as pixel values.
      - If `depth` is normalized to ~[0, 1], `sigma_color` should be small (e.g., 0.05–0.2).
      - If `depth` is metric / unbounded, values <= 1.0 are interpreted as a *fraction of dynamic range*
        (a practical convenience for configs that don't know the depth scale in advance).

    Forward-looking upgrade (implemented best-effort):
      - If OpenCV-contrib is available (`cv2.ximgproc.jointBilateralFilter`), we use the RGB image as guidance for
        sharper edge preservation. Falls back cleanly if unavailable.

    Args:
        depth: Depth map to filter (2D). Prefer float32.
        image: Reference image (H, W, 3) guidance for joint bilateral if available.
        sigma_color: Color/range sigma (see notes above).
        sigma_space: Spatial sigma (pixels).

    Returns:
        Filtered depth map (float32)
    """
    # Fast-exit: nothing to do / disabled
    if sigma_space <= 0 or sigma_color <= 0:
        return depth.astype(np.float32, copy=False)

    # Prefer OpenCV (SIMD-accelerated) when available.
    try:
        import cv2  # type: ignore
    except Exception:
        cv2 = None  # type: ignore

    if cv2 is not None:
        try:
            depth_f32 = depth.astype(np.float32, copy=False)
            if depth_f32.ndim != 2:
                depth_f32 = np.squeeze(depth_f32)
            if depth_f32.ndim != 2:
                raise ValueError(f"Expected 2D depth map, got shape {depth.shape}")

            if not depth_f32.flags["C_CONTIGUOUS"]:
                depth_f32 = np.ascontiguousarray(depth_f32)

            # Robust min/max ignoring NaNs/Infs
            finite = np.isfinite(depth_f32)
            if not finite.any():
                return depth_f32

            minv = float(depth_f32[finite].min())
            maxv = float(depth_f32[finite].max())
            rng = max(1e-8, maxv - minv)
            looks_normalized = (minv >= -0.5) and (maxv <= 1.5)

            sigma_color_scaled = float(sigma_color)

            # Back-compat + ergonomic heuristics:
            # - Normalized depth: allow legacy "0-255-ish" sigmaColor values (e.g., 25.5) and downscale to ~0.1.
            # - Unnormalized depth: treat sigmaColor <= 1.0 as a fraction of dynamic range.
            if looks_normalized:
                if sigma_color_scaled > 1.0:
                    sigma_color_scaled /= 255.0
            else:
                if sigma_color_scaled <= 1.0:
                    sigma_color_scaled *= rng

            # d: neighborhood diameter (0 lets OpenCV derive from sigmaSpace).
            d = int(round(float(sigma_space) * 2 + 1)) if sigma_space > 0 else 0
            if d > 0 and d % 2 == 0:
                d += 1

            # Optional: joint bilateral filtering (depth smoothed using RGB guidance)
            try:
                if image is not None and getattr(image, "ndim", 0) == 3 and image.shape[:2] == depth_f32.shape:
                    ximgproc = getattr(cv2, "ximgproc", None)
                    joint_fn = getattr(ximgproc, "jointBilateralFilter", None) if ximgproc is not None else None
                    if joint_fn is not None:
                        guide = image.astype(np.float32, copy=False)
                        # Normalize guide to ~[0, 1] if it looks like uint8.
                        if guide.size and float(np.nanmax(guide)) > 1.5:
                            guide = guide / 255.0
                        if not guide.flags["C_CONTIGUOUS"]:
                            guide = np.ascontiguousarray(guide)

                        filtered = joint_fn(
                            guide,
                            depth_f32,
                            d=d,
                            sigmaColor=sigma_color_scaled,
                            sigmaSpace=float(sigma_space),
                        )
                        return filtered.astype(np.float32, copy=False)
            except Exception:
                # Best-effort: if anything about guidance filtering fails, fall back to regular bilateral.
                pass

            filtered = cv2.bilateralFilter(
                depth_f32,
                d=d,
                sigmaColor=sigma_color_scaled,
                sigmaSpace=float(sigma_space),
            )
            return filtered.astype(np.float32, copy=False)

        except Exception as e:
            logger.debug(
                f"OpenCV bilateral filtering failed ({type(e).__name__}: {e}); falling back to scipy gaussian_filter."
            )

    # Minimal fallback (not edge-preserving, but stable)
    from scipy.ndimage import gaussian_filter

    return gaussian_filter(depth.astype(np.float32, copy=False), sigma=float(sigma_space) / 3.0)

    def _preserve_edges(self, depth: np.ndarray, image: np.ndarray, threshold: float) -> np.ndarray:
        gray = np.mean(image, axis=2) if image.ndim == 3 else image
        from scipy.ndimage import sobel

        mag = np.hypot(sobel(gray, axis=0), sobel(gray, axis=1))
        mag = mag / (mag.max() + 1e-8)
        # Simple mask-based preservation logic (placeholder for more complex logic)
        # In production, this would likely blend based on edge magnitude
        return depth

    def fuse_multiview(self, results: List[DepthResult]) -> DepthResult:
        """Simple fusion stub."""
        if not results:
            raise ValueError("No results to fuse")
        depths = np.stack([r.depth_map for r in results], axis=0)

        if self.config.fusion_mode == "mean":
            fused = np.mean(depths, axis=0)
        elif self.config.fusion_mode == "median":
            fused = np.median(depths, axis=0)
        else:
            fused = np.mean(depths, axis=0)  # Default

        return DepthResult(fused, results[0].original_image, metadata={"fusion_mode": self.config.fusion_mode})